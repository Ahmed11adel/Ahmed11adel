# True Capital - Real Estate Cold Calling Website

This project is a full-stack website for a real estate cold calling service.

## 📁 Project Structure

```
truecapital-site/
├── backend/
│   └── index.js         # Node.js backend server
├── public/
│   ├── success.html     # Confirmation page after form submission
│   └── admin.html       # Admin dashboard (requires authentication)
```

## 🔧 Setup Instructions

### 1. Clone or Extract
Unzip the project or clone from your repo.

### 2. Install Dependencies
Navigate to the backend folder and install required packages:

```bash
cd backend
npm install express cors body-parser nodemailer mongoose express-basic-auth dotenv
```

### 3. Environment Variables
Create a `.env` file in `backend/` with the following content:

```
EMAIL_USER=your_gmail@gmail.com
EMAIL_PASS=your_gmail_app_password
EMAIL_RECEIVER=receiver@gmail.com
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/dbname
ADMIN_USER=admin
ADMIN_PASS=securepassword
PORT=3000
```

### 4. Start the Server
```bash
node index.js
```

### 5. Access the Website
- Form: `http://localhost:3000`
- Admin Dashboard: `http://localhost:3000/admin.html` (requires basic auth)

## ✅ Features
- Real estate service landing page
- Cold calling service plans
- Booking form with MongoDB + Email
- Admin dashboard to review submissions
- Confirmation page after submission

---

🛡️ Secured using Basic Authentication for the admin dashboard.
